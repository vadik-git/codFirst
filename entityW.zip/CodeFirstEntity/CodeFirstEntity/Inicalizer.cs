﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstEntity
{
    /*• артисти – ім'я, прізвище, країна (окрема таблиця)
• альбоми – ім'я, артист, рік, жанр (окрема таблиця)
• треки – ім'я, альбом, тривалість
• плейлисти – ім'я, треки, категорія (окрема таблиця)*/
    class Inicalizer : DropCreateDatabaseAlways<ModelMusicColection>
    {

        protected override void Seed(ModelMusicColection context)
        {
            base.Seed(context);

            var c1 = context.Countries.Add(new Country() { NameCountry = "USA" });
            var c2 = context.Countries.Add(new Country() { NameCountry = "SPAIN" });
            var c3 = context.Countries.Add(new Country() { NameCountry = "UKRAINE" });
            context.SaveChanges();
            var g1 = context.Genres.Add(new Genre() { Name = "HIP-HOP" });
            var g2 = context.Genres.Add(new Genre() { Name = "POP" });
            var g3 = context.Genres.Add(new Genre() { Name = "REP" });
            context.SaveChanges();
            var cat1 = context.Categories.Add(new Category() { Name="Lovely"});
            var cat2 = context.Categories.Add(new Category() { Name = "Relax" });
            var cat3 = context.Categories.Add(new Category() { Name = "Mood" });
            context.SaveChanges();
            var art1 = context.Artists.Add(new Artist() { Name="Vadim",Surname="Slobodzyan",CountryId=c1.Id});
            var art2 = context.Artists.Add(new Artist() { Name = "Valik", Surname = "Demidov", CountryId = c2.Id });
            var art3 = context.Artists.Add(new Artist() { Name = "Toxa", Surname = "Pauchek", CountryId = c3.Id });
            context.SaveChanges();
            var alb1 = context.Albums.Add(new Album() { Name="BadBoy",ArtistId=art1.Id,Year=new DateTime(2020,1,1),GanreId=g1.Id});
            var alb2 = context.Albums.Add(new Album() { Name = "River", ArtistId = art2.Id, Year = new DateTime(2019, 1, 1), GanreId = g2.Id });
            var alb3 = context.Albums.Add(new Album() { Name = "BadBoy", ArtistId = art3.Id, Year = new DateTime(2010, 1, 1), GanreId = g3.Id });
            context.SaveChanges();
            
            var trck1 = context.Tracks.Add(new Track() { Name="Panda",AlbumId=alb1.Id,Duration=new TimeSpan(00,03,17)});
            var trck2 = context.Tracks.Add(new Track() { Name = "Malinka", AlbumId = alb2.Id, Duration = new TimeSpan(00, 05, 07) });
            var trck3 = context.Tracks.Add(new Track() { Name = "Panda", AlbumId = alb3.Id, Duration = new TimeSpan(00, 04, 19)});
            context.SaveChanges();

            var pl1 = context.PlayLists.Add(new PlayList() { Name="Summer",CatergoryId=cat2.Id});
            pl1.Tracks.Add(trck1);
            pl1.Tracks.Add(trck2);
            pl1.Tracks.Add(trck3);
            context.SaveChanges();
            var pl2 = context.PlayLists.Add(new PlayList() { Name = "Holod", CatergoryId = cat3.Id });
            pl2.Tracks.Add(trck1);
            pl2.Tracks.Add(trck2);
            context.SaveChanges();
            var pl3 = context.PlayLists.Add(new PlayList() { Name = "BigMusc", CatergoryId = cat1.Id });
            pl3.Tracks.Add(trck2);
            pl3.Tracks.Add(trck3);
            context.SaveChanges();

             


        }

    }
}
