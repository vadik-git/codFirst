﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstEntity
{
    class Program
    {

        class Service
        {
            ModelMusicColection data = new ModelMusicColection();

            public IQueryable<Country> GetCountry()
            {
                return data.Countries;
            }


           public void createPlayList(PlayList playlist)
            {

                data.PlayLists.Add(playlist);
                data.SaveChanges();

            }


            public IQueryable<PlayList> GetPlay()
            {
               return data.PlayLists;
            }



        }
        static void Main(string[] args)
        {

            Service data = new Service();

            /// add playlist
            PlayList p1 = new PlayList() {

                Name="MyPlayList",
                CatergoryId=3
            };
            
            data.createPlayList(p1);

            //create track
            Track t1 = new Track()
            {
                Name = "Molods",
                AlbumId = 1,
                Duration = new TimeSpan(00, 03, 19)


            };
            //add track playlist
            p1.Tracks.Add(t1);
            Console.WriteLine("TRACK ADD AND PLAY LIST");

        }
    }
}
