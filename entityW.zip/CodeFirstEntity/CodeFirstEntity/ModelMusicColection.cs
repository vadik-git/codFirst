﻿namespace CodeFirstEntity
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity;
    using System.Linq;

    public class ModelMusicColection : DbContext
    {
        
        public ModelMusicColection()
            : base("name=ModelMusicColection")
        {
            Database.SetInitializer(new Inicalizer());
        }



        // public virtual DbSet<MyEntity> MyEntities { get; set; }



        public virtual DbSet<Country> Countries { get; set; }
        public virtual DbSet<Artist> Artists { get; set; }
        public virtual DbSet<Album> Albums { get; set; }
        public virtual DbSet<Track> Tracks { get; set; }
        public virtual DbSet<PlayList> PlayLists{ get; set; }
        public virtual DbSet<Genre> Genres{ get; set; }
        public virtual DbSet<Category> Categories { get; set; }
    }


    /*• артисти – ім'я, прізвище, країна (окрема таблиця)
• альбоми – ім'я, артист, рік, жанр (окрема таблиця)
• треки – ім'я, альбом, тривалість
• плейлисти – ім'я, треки, категорія (окрема таблиця)*/

    public class Country
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string NameCountry { get; set; }

        //////////   
        public virtual ICollection<Artist> Artists { get; set; }

    }

    public class Artist
    {

        public int Id { get; set; }

        [Required]
        [StringLength(100)]

        public string Name { get; set; }

        [Required]
        [StringLength(100)]
        public string Surname { get; set; }
        [ForeignKey(nameof(Country))]
        public int CountryId { get; set; }

    
        //Navigattion

        public virtual Country Country { get; set; }

        //many to many
        public virtual ICollection<Album> Albums { get; set; }


    }


    public class Album
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]

        public string Name { get; set; }

        public DateTime Year { get; set; }


        [ForeignKey(nameof(Artist))]
        public int ArtistId { get; set; }
        [ForeignKey(nameof(Ganre))]
        public int GanreId { get; set; }


        //nav
        public Artist Artist { get; set; }
        public Genre Ganre{ get; set; }

        //
        public ICollection<Track> Tracks { get; set; }
                                           

        

    }





    public class Track
    {
        
        public int Id { get; set; }

        [Required]
        [StringLength(100)]

        public string Name { get; set; }
        [ForeignKey(nameof(Album))]
        public int AlbumId { get; set; }

        

        public TimeSpan Duration { get; set; }

        //
        public Album Album { get; set; }
        public  PlayList PlayList { get; set; }


        //

    }




    public class PlayList
    {

        public PlayList()
        {
            Tracks = new HashSet<Track>();
        }
        public int Id { get; set; }

        [Required]
        [StringLength(100)]

        public string Name { get; set; }


        public int CatergoryId { get; set; }

        public Category Category{ get; set; }
        //
        public ICollection<Track>Tracks { get; set; }

    }




    public class Genre
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]

        public string Name { get; set; }



        public ICollection<Album>Albums { get; set; }



    }


    public class Category
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]

        public string Name { get; set; }



        public ICollection<PlayList> playLists { get; set; }

    }





}